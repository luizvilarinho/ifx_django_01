from django.contrib.auth.models import User
from django.db import models
from pytz import timezone

class AuthTokenUser(models.Model):
    key = models.TextField(primary_key=True)
    user_id = models.TextField(blank=False, null=False)

    class Meta:
        managed = False
        db_table = 'authtoken_token'
        
