from sessioncollection.models import AuthTokenUser
from rest_framework import viewsets
from .serializers import sessioncollectionSerializer


class sessioncollectionViewSet(viewsets.ModelViewSet):

    queryset = AuthTokenUser.objects.all()
    serializer_class = sessioncollectionSerializer