from sessioncollection.models import AuthTokenUser
from rest_framework import serializers


class sessioncollectionSerializer(serializers.ModelSerializer):

    class Meta:
        model = AuthTokenUser
        fields = ('key','user_id')
        
        
