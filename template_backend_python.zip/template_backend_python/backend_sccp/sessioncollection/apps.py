from django.apps import AppConfig


class SessioncollectionConfig(AppConfig):
    name = 'sessioncollection'
