from usuarios.models import AuthUser
from rest_framework import viewsets
from .serializers import usuariosSerializer


class usuariosViewSet(viewsets.ModelViewSet):

    queryset = AuthUser.objects.all()
    serializer_class = usuariosSerializer