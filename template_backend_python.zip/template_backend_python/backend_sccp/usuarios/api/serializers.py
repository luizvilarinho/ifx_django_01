from usuarios.models import AuthUser
from rest_framework import serializers, status
from rest_framework.serializers import ModelSerializer
from django.contrib.auth.hashers import make_password
from rest_framework.response import Response
from django.db.migrations import serializer
import traceback
from django.http import HttpResponse

class usuariosSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = AuthUser
        fields = ['id', 'password', 'username', 'first_name', 'last_name', 'email', 'is_active']
        
    def create(self, validated_data):
            password = make_password(validated_data.pop('password'))
            return AuthUser.objects.create(password=password, **validated_data)
        
        
    def update(self, validated_data, var2):
        if (var2['password'] == ''):
            print(validated_data.password)
            AuthUser.objects.filter(id=validated_data.id).update(first_name = var2['first_name'],last_name = var2['last_name'], email = var2['email'] )
            try:
                return HttpResponse(self)   
            except Exception:
                traceback.print_exc()
                return HttpResponse(self) 
        else:
            password = make_password(var2['password'])
            print(validated_data.password)
            AuthUser.objects.filter(id=validated_data.id).update(password=password,first_name = var2['first_name'],last_name = var2['last_name'], email = var2['email'] )
            try:
                return HttpResponse(self)   
            except Exception:
                traceback.print_exc()
                return HttpResponse(self)   
     
        
