from django.contrib.auth.models import User
from django.db import models
from pytz import timezone
from django.contrib.admin import forms

class AuthUser(models.Model):
    password = models.TextField(max_length=100,  blank=True)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.BooleanField(default=False)
    username = models.TextField(unique=True)
    first_name = models.TextField()
    last_name = models.TextField()
    email = models.TextField()
    is_staff = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    date_joined = models.DateTimeField(auto_now_add=True, blank=True)

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    id = models.BigIntegerField(primary_key=True)
    user = models.ForeignKey(AuthUser, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        
        
class AuthUserToken(models.Model):
    user = models.ForeignKey(AuthUser, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'authtoken_token'

