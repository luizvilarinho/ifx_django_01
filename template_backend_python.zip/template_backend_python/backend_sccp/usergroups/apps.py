from django.apps import AppConfig


class UsergroupsConfig(AppConfig):
    name = 'usergroups'
