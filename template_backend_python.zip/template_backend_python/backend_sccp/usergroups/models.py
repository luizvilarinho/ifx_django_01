from django.contrib.auth.models import User
from django.db import models
from pytz import timezone

# Create your models here.

class userGroups(models.Model):
    name = models.TextField()

    class Meta:
        managed = False
        db_table = 'auth_group'