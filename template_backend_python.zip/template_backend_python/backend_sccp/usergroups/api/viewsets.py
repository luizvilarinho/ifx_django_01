from usergroups.models import userGroups
from rest_framework import viewsets
from .serializers import userGroupSerializer


class userGroupViewSet(viewsets.ModelViewSet):
    queryset = userGroups.objects.all()
    serializer_class = userGroupSerializer