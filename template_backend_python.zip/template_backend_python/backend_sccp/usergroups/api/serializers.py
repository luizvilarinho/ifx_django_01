from usergroups.models import userGroups
from rest_framework import serializers


class userGroupSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = userGroups
        fields = ['id', 'name']
