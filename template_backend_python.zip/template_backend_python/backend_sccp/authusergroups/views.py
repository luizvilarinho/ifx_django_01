from django.shortcuts import render
from django.http import HttpResponse
from authusergroups.models import authUserGroups

def getUserGroup(request, user_id):
    data = {'resultado': authUserGroups.objects.filter(user_id = user_id)}
    
    return render(request, 'queryusergroup.html', data )