from django.apps import AppConfig


class AuthusergroupsConfig(AppConfig):
    name = 'authusergroups'
