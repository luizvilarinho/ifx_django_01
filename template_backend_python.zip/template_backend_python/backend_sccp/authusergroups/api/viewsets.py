from authusergroups.models import authUserGroups
from rest_framework import viewsets
from .serializers import authUserGroupsSerializer

class authUserViewSet(viewsets.ModelViewSet):

    queryset = authUserGroups.objects.all()
    serializer_class = authUserGroupsSerializer

