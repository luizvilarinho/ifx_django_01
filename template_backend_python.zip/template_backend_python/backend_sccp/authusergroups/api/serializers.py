from authusergroups.models import authUserGroups
from rest_framework import serializers


class authUserGroupsSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = authUserGroups
        fields = ['id', 'user_id','group_id']
            
        serializer_class = authUserGroups


      
     