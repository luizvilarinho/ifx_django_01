from django.contrib.auth.models import User
from django.db import models
from pytz import timezone

# Create your models here.

class authUserGroups(models.Model):
    user_id = models.IntegerField(blank=True, null=True)
    group_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        
